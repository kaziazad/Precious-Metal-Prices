<?php
/**
 * Plugin Name: Metal Prices Live
 * Plugin URI: http://www.metalprices.com
 * Description: Realtime metal prices of international market. It's included all Precious Metal Prices. Such as Gold, Silver, Platinum, Palladium, GOFO/LIBOR.
 * Version: 1.0
 * Author: Kazi Mahmud Al Azad
 * Author URI: http://www.mysite.com
 */


if ( ! defined( 'ABSPATH' ) ) {
	return;
}

require_once(dirname(__FILE__).'/lib/codestar-framework/codestar-framework.php');


class MP_MetalPrices{


    public function __construct(){

        add_action('wp_enqueue_scripts', array( $this,'metal_price_style'));
       



    }

    function metal_price_style(){
        wp_enqueue_style('bootstap', plugins_url('/assets/css/bootstrap.min.css', __FILE__));
        wp_enqueue_style('customstyle', plugins_url('/assets/css/style.css',__FILE__));
    
        wp_enqueue_script('jquery-metal', plugins_url('/assets/js/jquery-3.6.js', __FILE__), array(), '', true);
        wp_enqueue_script('customscript-metal', plugins_url('/assets/js/scripts.js', __FILE__), array("jquery"), '', true);
    
    }

    public function shortcode(){

        add_shortcode('metal-prices', array($this, 'mp_metal_prices' ));
    }


    function mp_metal_prices(){

        ob_start();?>
    
    <div class="container col-sm-6 col-md-8 col-lg-9 col-xl-10">
            <h1 class="bg-primary">Precious Metal Prices</h1>
          
            <select class="metalYear" id="queryMetal" value="select">
                <option value="gold">Gold</option>
                <option value="silver">Silver</option>
                <option value="gofo">GOFO/LIBOR</option>
                <option value="platinum">Platinum</option>
                <option value="palladium">Palladium</option>
            </select>
           
            <select class="metalYear" id="queryYear" value="select"> 
                
                <option value="2022">2022</option>
                <option value="2021">2021</option>
                <option value="2020">2020</option>
                <option value="2019">2019</option>
                <option value="2018">2018</option>
                <option value="2017">2017</option>
                <option value="2016">2016</option>
                <option value="2015">2015</option>
                <option value="2014">2014</option>
                <option value="2013">2013</option>
                <option value="2012">2012</option>
                <option value="2011">2011</option>
                <option value="2010">2010</option>
            </select>
            
    
            <!-- gold -->
        <div class="table-responsive">
            <table class="table table-sm table-striped tableclass goldtable hide-me">
    
                <tr>
                    <th></th>
                    <th colspan="2">USD $</th>
                    <th colspan="2">GBP £</th>
                    <th colspan="2">EUR €</th>
                </tr>
    
                <tr>
                    <th>Date</th>
                    <th>AM</th>
                    <th>PM</th>
                    <th>AM</th>
                    <th>PM</th>
                    <th>AM</th>
                    <th>PM</th>
                </tr>
                <tbody id="tablecontainer-gold">
    
                </tbody>
               
    
                </table>
        </div>
    
    
            <!-- silver -->
    
            <table class="table table-striped tableclass silvertable hide-me">
    
                <tr>
                    <th></th>
                    <th>USD $</th>
                    <th>GBP £</th>
                    <th>EUR €</th>
                </tr>
    
                <tr>
                    <th>Date</th>
                    <th></th>
    
                    <th></th>
                    
                    <th></th>
                   
                </tr>
    
                <tbody id="tablecontainer-silver">
    
                </tbody>
    
               
    
            </table>
    
            <!-- Gofu libor -->
    
            <table class="table table-striped tableclass gofutable hide-me">
    
                <tr>
                    <th></th>
                    <th colspan="5">GOFU</th>
                    <th colspan="5">LIBOR</th>
                    <th colspan="5">GOFU/LIBOR</th>
                </tr>
    
                <tr>
                    <th>Date</th>
                    <th>1 Month</th>
                    <th>2 Month</th>
                    <th>3 Month</th>
                    <th>6 Month</th>
                    <th>12 Month</th>
                    <th>1 Month</th>
                    <th>2 Month</th>
                    <th>3 Month</th>
                    <th>6 Month</th>
                    <th>12 Month</th>
                    <th>1 Month</th>
                    <th>2 Month</th>
                    <th>3 Month</th>
                    <th>6 Month</th>
                    <th>12 Month</th>
                   
                    
                
                </tr>
    
                <tbody id="table-gofu-libor">
    
                </tbody>
    
    
    
    
            </table>
    
            <!-- Platinum -->
    
            <table class="table table-striped tableclass platinumtable hide-me">
    
                <tr>
                    <th></th>
                    <th colspan="2">USD $</th>
                    <th colspan="2">GBP £</th>
                    <th colspan="2">EUR €</th>
                </tr>
    
                <tr>
                    <th>Date</th>
                    <th>AM</th>
                    <th>PM</th>
                    <th>AM</th>
                    <th>PM</th>
                    <th>AM</th>
                    <th>PM</th>
                </tr>
    
                <tbody id="tablecontainer-platinum">
    
                </tbody>
    
               
    
            </table>
    
            <!-- palladium -->
    
            <table class="table table-striped tableclass palladiumtable hide-me">
    
                <tr>
                    <th></th>
                    <th colspan="2">USD $</th>
                    <th colspan="2">GBP £</th>
                    <th colspan="2">EUR €</th>
                </tr>
    
                <tr>
                    <th>Date</th>
                    <th>AM</th>
                    <th>PM</th>
                    <th>AM</th>
                    <th>PM</th>
                    <th>AM</th>
                    <th>PM</th>
                </tr>
                <tbody id="tablecontainer-palladium">
    
                </tbody>
    
               
    
            </table>
            
       
        </div>
        
    
    
        <?php return ob_get_clean();
    }
    
   
    
}



if(class_exists('MP_MetalPrices')){
$metalPrices =  new MP_MetalPrices();
$metalPrices->shortcode();



// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'metal_prices';
  
    //
    // Create options
    CSF::createOptions( $prefix, array(
      'menu_title' => 'Metal Prices Options',
      'menu_slug'  => 'metal-settings',
      'framework_title'         => 'Precious Metal Prices<small> by Azad</small>',
    ) );
  
    //
    // Create a section
    CSF::createSection( $prefix, array(
      'title'  => 'Shortcod',
      
      'fields' => array(
  
        //
        // A text field

        array(
            'id'         => 'metal-shortcode',
            'type'       => 'text',
            'title'      => 'Shortcode',
            'default'    => 'Use this shortcode: [metal-prices]',
            'attributes' => array(
              'readonly' => 'readonly',
            ),
        
        ),
  
      )
    ) );
  
   
  }




}

?>

 