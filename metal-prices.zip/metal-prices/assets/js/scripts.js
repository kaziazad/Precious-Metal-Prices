jQuery(document).ready(function($){

  $(".container").ready(
    function(){
  
      var defaultYear = new Date().getFullYear();
      var defaultMetal = "gold";
      
  $(".goldtable").removeClass("hide-me");
        $(".silvertable, .gofutable, .platinumtable, .palladiumtable").addClass("hide-me");
         
        const urlam = "http://localhost/ajax-practice/json/golddataam.json?";

        const urlpm = "http://localhost/ajax-practice/json/golddatapm.json?";

        var dataQueryAm = $.ajax({ 
            dataType: "json",
            url: urlam,
            async: true,
            success: function(result) {}                     
          });
          
          
          var dataQueryPm = $.ajax({ 
            dataType: "json",
            url: urlpm,
            async: true,
            success: function(result) {}  
          });

          $.when( dataQueryAm , dataQueryPm, defaultYear  ).done(function( arg, arg1, arg2 ) {
          
            var goldAm = arg[0].reverse();
            var goldPm = arg1[0].reverse();

            var output = "";
            for (let i = 0; i < goldAm.length; i++) {

                var yearCut = (goldAm[i].d).slice(0, 4);

                if(arg2 == yearCut){

                output += "<tr><td>" + goldAm[i].d + "</td>" + "<td>" + goldAm[i].v[0] + "</td>" + "<td>" + goldPm[i].v[0] + "</td>" + "<td>" + goldAm[i].v[1] + "</td>" + "<td>" + goldPm[i].v[1] + "</td>" + "<td>" + goldAm[i].v[2] + "</td>" + "<td>" + goldPm[i].v[2] + "</td></tr>";
                
                $("#tablecontainer-gold").html(output);

                }
                          
            }
        
          });
        
        });

    $("#queryMetal, #queryYear").change(function(){

        var selectedMetal = $("#queryMetal").val();

        var selectedYear = $("#queryYear").val();

        if(selectedMetal == "gold"){

           goldPrice(selectedMetal, selectedYear);


        } else if(selectedMetal == "silver") {

            silverPrice(selectedMetal, selectedYear);

        } else if(selectedMetal == "gofo") {

            gofuPrice(selectedMetal, selectedYear);

        }else if(selectedMetal == "platinum") {

            platinumPrice(selectedMetal, selectedYear);

        }else if(selectedMetal == "palladium") {

            palladiumPrice(selectedMetal, selectedYear);
        }

    });

    function goldPrice(data, data1){
      
        $(".goldtable").removeClass("hide-me");
        $(".silvertable, .gofutable, .platinumtable, .palladiumtable").addClass("hide-me");

        const urlam = "http://localhost/ajax-practice/json/golddataam.json?";

        const urlpm = "http://localhost/ajax-practice/json/golddataPm.json?";
        



        var dataQueryAm = $.ajax({ 
            dataType: "json",
            url: urlam,
            async: true,
            success: function(result) {}                     
          });
          
          
          var dataQueryPm = $.ajax({ 
            dataType: "json",
            url: urlpm,
            async: true,
            success: function(result) {}  
          });

   

          $.when( dataQueryAm , dataQueryPm  ).done(function( arg, arg1 ) {
          
            var goldAm = arg[0].reverse();
            var goldPm = arg1[0].reverse();

            

            var output = "";
            for (let i = 0; i < goldAm.length; i++) {

                var yearCut = (goldAm[i].d).slice(0, 4);

                if(data1 == yearCut){

                output += "<tr><td>" + goldAm[i].d + "</td>" + "<td>" + goldAm[i].v[0] + "</td>" + "<td>" + goldPm[i].v[0] + "</td>" + "<td>" + goldAm[i].v[1] + "</td>" + "<td>" + goldPm[i].v[1] + "</td>" + "<td>" + goldAm[i].v[2] + "</td>" + "<td>" + goldPm[i].v[2] + "</td></tr>";
                
                $("#tablecontainer-gold").html(output);

                }
                          
            }
        
          });
        
    };

    function silverPrice(data, data1){
        
        $(".silvertable").removeClass("hide-me");
        $(".goldtable, .gofutable, .platinumtable, .palladiumtable").addClass("hide-me");

        const urlsilver = "http://localhost/ajax-practice/json/silverdata.json";


        var dataQuerySilver = $.ajax({ 
            dataType: "json",
            url: urlsilver,
            async: true,
            success: function(result) {}                     
          });
          
          
          $.when( dataQuerySilver ).done(function( silverArg ) {
          
            var silver = silverArg.reverse();


            var output = "";
            for (let i = 0; i < silver.length; i++) {

                var yearCut = (silver[i].d).slice(0, 4);

                if(data1 == yearCut){

                output += "<tr><td>" + silver[i].d + "</td>" + "<td>" + silver[i].v[0] + "</td>" + "<td>" + silver[i].v[1] + "</td>" + "<td>" + silver[i].v[2] + "</td></tr>";
                
                $("#tablecontainer-silver").html(output);

                }
                          
            }
        
          });
    };




    function gofuPrice(data, data1){
       
      
        $(".gofutable").removeClass("hide-me");
        $(".goldtable, .silvertable, .platinumtable, .palladiumtable").addClass("hide-me");

        const urlgofu = "http://localhost/ajax-practice/json/gofo.json";

        const urllibor = "http://localhost/ajax-practice/json/libor.json";

        const urlgofolibor = "http://localhost/ajax-practice/json/libor.json";


        var dataQuerygofu = $.ajax({ 
            dataType: "json",
            url: urlgofu,
            async: true,
            success: function(result) {}                     
          });
          
        var dataQuerylibor = $.ajax({ 
            dataType: "json",
            url: urllibor,
            async: true,
            success: function(result) {}                     
          });

        var dataQueryGofolibor = $.ajax({ 
            dataType: "json",
            url: urlgofolibor,
            async: true,
            success: function(result) {}                     
          });
          
          $.when( dataQuerygofu, dataQuerylibor, dataQueryGofolibor ).done(function( gofuArg, liborArg, gofoLiborArg ) {
          
            var gofu = gofuArg[0].reverse();

            var libor = liborArg[0].reverse();

            var gofoLibor = gofoLiborArg[0].reverse();

            var output = "";
            for (let i = 0; i < gofu.length; i++) {
       
                var yearCut = (gofu[i].d).slice(0, 4);
                
                if(data1 == yearCut){

                 output += "<tr><td>" + gofu[i].d + "</td>" + "<td>" + gofu[i].v[0] + "</td>" + "<td>" + gofu[i].v[1] + "</td>" + "<td>" + gofu[i].v[2] + "</td>" + "<td>" + gofu[i].v[3] + "</td>" + "<td>" + gofu[i].v[4] + "</td>" + "<td>" + libor[i].v[0] + "</td>" + "<td>" + libor[i].v[1] + "</td>" + "<td>" + libor[i].v[2] + "</td>" + "<td>" + libor[i].v[3] + "</td>" + "<td>" + libor[i].v[4] + "</td>" + "<td>" + gofoLibor[i].v[0] + "</td>" + "<td>" + gofoLibor[i].v[1] + "</td>" + "<td>" + gofoLibor[i].v[2] + "</td>" + "<td>" + gofoLibor[i].v[3] + "</td>" + "<td>" + gofoLibor[i].v[4] + "</td></tr>";
                
                $("#table-gofu-libor").html(output);
                    
                }
                          
            }
        
          });
    };

    function platinumPrice(data, data1){
        
        
        $(".platinumtable").removeClass("hide-me");
        $(".silvertable, .gofutable, .goldtable, .palladiumtable").addClass("hide-me");

        const urlam = "http://localhost/ajax-practice/json/platinumAm.json";

        const urlpm = "http://localhost/ajax-practice/json/platinumPm.json";


        var dataQueryAm = $.ajax({ 
            dataType: "json",
            url: urlam,
            async: true,
            success: function(result) {}                     
          });
          
          
          var dataQueryPm = $.ajax({ 
            dataType: "json",
            url: urlpm,
            async: true,
            success: function(result) {}  
          });
          
          $.when( dataQueryAm , dataQueryPm  ).done(function( arg, arg1 ) {
          
            var platinumAm = arg[0].reverse();
            var platinumPm = arg1[0].reverse();

            var output = "";
            for (let i = 0; i < platinumAm.length; i++) {

                var yearCut = (platinumAm[i].d).slice(0, 4);
            
                if(data1 == yearCut){

                output += "<tr><td>" + platinumAm[i].d + "</td>" + "<td>" + platinumAm[i].v[0] + "</td>" + "<td>" + platinumPm[i].v[0] + "</td>" + "<td>" + platinumAm[i].v[1] + "</td>" + "<td>" + platinumPm[i].v[1] + "</td>" + "<td>" + platinumAm[i].v[2] + "</td>" + "<td>" + platinumPm[i].v[2] + "</td></tr>";
                
                $("#tablecontainer-platinum").html(output);

                }
                          
            }
        
          });
    };


    function palladiumPrice(data, data1){
        

        $(".palladiumtable").removeClass("hide-me");
        $(".silvertable, .gofutable, .goldtable, .platinumtable").addClass("hide-me");

        const urlam = "http://localhost/ajax-practice/json/palladiamAm.json";

        const urlpm = "http://localhost/ajax-practice/json/palladiamPm.json";


        var dataQueryAm = $.ajax({ 
            dataType: "json",
            url: urlam,
            async: true,
            success: function(result) {}                     
          });
          
          
          var dataQueryPm = $.ajax({ 
            dataType: "json",
            url: urlpm,
            async: true,
            success: function(result) {}  
          });
          
          $.when( dataQueryAm , dataQueryPm  ).done(function( arg, arg1 ) {
          
            var palladiumAm = arg[0].reverse();
            var palladiumPm = arg1[0].reverse();

           

            var output = "";
            for (let i = 0; i < palladiumAm.length; i++) {

                var yearCut = (palladiumAm[i].d).slice(0, 4);
             
                if(data1 == yearCut){

                output += "<tr><td>" + palladiumAm[i].d + "</td>" + "<td>" + palladiumAm[i].v[0] + "</td>" + "<td>" + palladiumPm[i].v[0] + "</td>" + "<td>" + palladiumAm[i].v[1] + "</td>" + "<td>" + palladiumPm[i].v[1] + "</td>" + "<td>" + palladiumAm[i].v[2] + "</td>" + "<td>" + palladiumPm[i].v[2] + "</td></tr>";
                
                $("#tablecontainer-palladium").html(output);

                }
                          
            }
        
          });
    };



});

